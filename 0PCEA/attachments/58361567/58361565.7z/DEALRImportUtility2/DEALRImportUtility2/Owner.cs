﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEALRImportUtility2
{
    public class Owner
    {
        public int readingListID { get; set; }

        /// <summary>
        /// The module code of the reading list specified by readingListID (needed because the above is the OLD reading list id, 
        /// se we need to find the new id by module code later (when generating the sql)
        /// </summary>
        public string readingListModuleCode { get; set; }

        public string fullname { get; set; }
        public string username { get; set; }
        public string email { get; set; }

        public DateTime lastModified { get; set; }

        public string GetFirstName()
        {
            string name = "";
            if(!string.IsNullOrEmpty(fullname))
            {
                if (fullname.Contains(" "))
                {
                    string[] names = fullname.Split(' ');
                    name = string.Join(" ", names.Take(names.Count() - 1).ToArray());
                }
            }
            return name;
        }


        public string GetLastName()
        {
            string name = "";
            if (!string.IsNullOrEmpty(fullname))
            {
                if (fullname.Contains(" "))
                {
                    string[] names = fullname.Split(' ');
                    name = names.Last();
                }
            }
            return name;
        }

        public override string ToString()
        {
            return "RL: " + readingListID + ", " +
                   "First Name: " + GetFirstName() + ", " +
                   "Last Name: " + GetLastName() + ", " +
                   "Username: " + username + ", " +
                   "Email: " + email + ", " +
                   "Last Modified: " + lastModified.ToString("dd-MMM-yyyy HH:mm:ss");
        }

        public override bool Equals(Object o)
        {
            if (o == null) return false;
            if (this.username.ToUpper().Equals(((Owner)o).username.ToUpper())) {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return username.GetHashCode();
        }

    }
}
