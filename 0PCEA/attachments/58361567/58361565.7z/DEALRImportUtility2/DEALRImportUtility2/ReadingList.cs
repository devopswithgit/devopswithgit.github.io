﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEALRImportUtility2
{
    public class ReadingList
    {
        public int ID { get; set; }
        public string ModuleCode { get; set; }
        public string ModuleTitle { get; set; }
        public string DeptCode { get; set; }
        public int SemesterID { get; set; }
        public int Year { get; set; }

        public override string ToString()
        {
            return "ID: " + ID + ", " +
                   "Module Code: " + ModuleCode + ", " +
                   "ModuleTitle: " + ModuleTitle + ", " +
                   "DeptCode: " + DeptCode + ", " +
                   "SemesterID: " + SemesterID + ", " +
                   "Year: " + Year;
        }

        public override bool Equals(Object o)
        {
            if (o == null) return false;
            if (this.ModuleCode.Equals(((ReadingList)o).ModuleCode))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return ModuleCode.GetHashCode();
        }
    }
}
