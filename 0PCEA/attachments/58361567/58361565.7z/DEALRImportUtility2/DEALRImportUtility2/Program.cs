﻿using DEALRImportUtility2;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace DEALRImportUtility
{
    public class Program
    {

        // Map the semester ids from the old LaSU db to the new dealr one
        static Dictionary<int, int> SemesterIDMap = new Dictionary<int, int>()
            {
                { 0, 1 },
                { 42, 2 },
                { 52, 3 },
                { 54, 4 },
                { 55, 5 },
                { 60, 6 },
                { 61, 7 },
                { 62, 8 },
                { 63, 9 },
                { 64, 10 },
                { 65, 11 },
                { 66, 12 },
                { 67, 13 },
                { 68, 14 }
            };

        static List<string> badOwnerDataRecords = new List<string>();
        static List<string> badOwnerDataRecordsButDontWorryAbout = new List<string>();

        public static void Main(string[] args)
        {
            

            // A full dictionary of owners. The key is the best version of a particular owner to import, and the value is a list of other owners
            // for the same person (matched on username) who have been rejected. This is because there are many many copies of the same user in the original LaSU database. 
            Dictionary<Owner, List<Owner>> ImportableOwners = new Dictionary<Owner, List<Owner>>();

            List<ReadingList> ReadingLists = new List<ReadingList>();
            List<ReadingList> RejectedReadingLists = new List<ReadingList>();
            List<Semester> Semesters = new List<Semester>();

            // string[] lines = System.IO.File.ReadAllLines(@"c:\work\dealr\lasu.sql");
            if(args == null || args.Count() < 1)           
            {
                Console.WriteLine("Please specify a filename for the LaSU export");                
            }
            else
            {
                string[] lines = System.IO.File.ReadAllLines(@"c:\work\dealr\initialrelease\LASU_PROD_16thNov2016.sql");
                //string filename = "C:\\work\\dealr\\LaSU_Production_Export_18_April_2016_10.45_small.sql";
                string filename = args[0];
                //string[] lines = System.IO.File.ReadAllLines(filename);
                foreach (string line in lines)
                {
                    if (line != null)
                    {
                        if (line.StartsWith("INSERT INTO `owner` VALUES"))
                        {
                            ImportOwners(line, ImportableOwners);
                        }
                        else if (line.StartsWith("INSERT INTO `readinglist` VALUES"))
                        {
                            ImportReadingLists(line, ReadingLists, RejectedReadingLists);
                        }
                        else if (line.StartsWith("INSERT INTO `semesters` VALUES"))
                        {
                            ImportSemesters(line, Semesters);
                        }
                    }
                }
                GenerateSQL(ImportableOwners, ReadingLists, Semesters);
                //ReadingListReport(ReadingLists, RejectedReadingLists);
                //OwnerReport()

                

                string[] accmanRecords = System.IO.File.ReadAllLines(@"c:\work\dealr\initialrelease\ValidAccountsNov.csv");
                List<AccmanRecord> AccmanAccounts = new List<AccmanRecord>();
                foreach (var record in accmanRecords)
                {
                    string[] columns = record.Split(',');
                    AccmanAccounts.Add(new AccmanRecord()
                    {
                        username = columns[0],
                        email = columns[1] + "@salford.ac.uk"
                    }
                    );
                }

                // Look for owners that had multiple record in LaSU where their email addresses differ
                //List<string> badOwnerDataRecords = new List<string>();
                foreach (var entry in ImportableOwners)
                {
                    if (entry.Value.Count > 0)
                    {
                        Owner best = entry.Key;

                        //if(best != null && best.email != null && "C.Smith@Salford.ac.uk".Equals(best.email))
                        if (best != null)
                        {
                            List<Owner> others = entry.Value;

                            bool differencesFound = false;
                            foreach (var otherOwner in others)
                            {
                                if (best.email != null && otherOwner != null && otherOwner.email != null)
                                {
                                    if (!best.email.ToUpper().Equals(otherOwner.email.ToUpper()))
                                    {
                                        differencesFound = true;
                                        break;
                                    }
                                }
                            }

                            if (differencesFound)
                            {
                                // First, see if the best choice was the right choice - are they present, and is their email address in DEALR different to how it is in Accman
                                AccmanRecord accmanRecord = AccmanAccounts.Where(x => best.username.ToUpper().Equals(x.username.ToUpper())).SingleOrDefault();
                                if (accmanRecord == null)
                                {
                                    // not present in accman, so dont worry about them
                                    //badOwnerDataRecordsButDontWorryAbout.Add()
                                }
                                else
                                {
                                    if (accmanRecord.email != null && best.email != null && !accmanRecord.email.ToUpper().Equals(best.email.ToUpper()))
                                    {
                                        // This is one that matters, so include it in the report
                                        string badOwnerDataEntry = best.username + " DEALR EMAIL: [" + best.email + "], Accman Email: [" + accmanRecord.email + "], ";
                                        foreach (var otherOwner in others)
                                        {
                                            badOwnerDataEntry += otherOwner.email + ", ";
                                        }
                                        badOwnerDataRecords.Add(badOwnerDataEntry);
                                    }
                                }
                            }
                        }

                    }
                }

                Console.WriteLine("Bad Owner Data Report");
                foreach (var record in badOwnerDataRecords)
                {
                    Console.WriteLine(record);
                }

            }            
        }

        public static void GenerateSQL(Dictionary<Owner, List<Owner>> ImportableOwners, List<ReadingList> ReadingLists, List<Semester> Semesters)
        {
            // Import the reading list data
            foreach (var list in ReadingLists)
            {
                string sql = string.Format("INSERT INTO ReadingList (ModuleCode, ModuleName, DepartmentCode, SemesterId, CreatedDate, LastModifiedDate) VALUES ('{0}', '{1}', '{2}', {3}, GETDATE(), GETDATE());", list.ModuleCode, list.ModuleTitle, list.DeptCode, list.SemesterID);
                Console.WriteLine(sql);
            }

            // Import the Owner data
            //var allowners = ImportableOwners.Keys.ToList().OrderBy(x => x.GetLastName()).ThenBy(x => x.GetLastName()).ToList();
            //foreach(var owner in allowners)
            //{
            //    Console.WriteLine(owner.GetLastName() + ", " + owner.GetLastName() + ", " + owner.username);
            //}

            //Console.WriteLine("There are " + ImportableOwners.Count + " owners");
            List<string> usernamesAlreadyInserted = new List<string>();
            List<string> duplicateUsernames = new List<string>();
            foreach (var kvp in ImportableOwners)
            {
                // Insert the owner
                Owner o = kvp.Key;
                if (usernamesAlreadyInserted.Contains(o.username.ToUpper()))
                {
                    duplicateUsernames.Add(o.username.ToUpper());
                    continue;
                }
                usernamesAlreadyInserted.Add(o.username.ToUpper());
                
                string sql = string.Format("INSERT INTO Owner (FIRSTNAME, LASTNAME, USERNAME, EMAIL, CreatedDate, LastModifiedDate) VALUES ('{0}', '{1}', '{2}', '{3}', GETDATE(), GETDATE());", o.GetFirstName(), o.GetLastName(), o.username, o.email);
                Console.WriteLine(sql);

                // Now get the moduleCode for the reading list because it's needed for the sql
                ReadingList rl = ReadingLists.Where(x => x.ID == o.readingListID).SingleOrDefault();
                if(rl != null && !string.IsNullOrEmpty(rl.ModuleCode))
                {
                    // Now insert the links for all of the reading lists
                    string firstLink = string.Format("INSERT INTO ReadingListOwner (OwnerId, ReadingListId) VALUES ((select id from owner where username = '{0}'), (select id from readinglist where modulecode = '{1}'));", o.username, rl.ModuleCode);
                    //Console.WriteLine(o.username + ": " + rl.ModuleCode + "(" + rl.ModuleTitle + ")");
                    Console.WriteLine(firstLink);
                }

                // And insert links to any others that they should be linked to, providing they are valid i.e. ended in "-16" and therefore will be in the ReadingLists collection
                foreach(Owner rejectedOwner in kvp.Value)
                {
                    ReadingList rejectedRl = ReadingLists.Where(x => x.ID == rejectedOwner.readingListID).SingleOrDefault();
                    if (rejectedRl != null && !string.IsNullOrEmpty(rejectedRl.ModuleCode))
                    {
                        // Now insert the links for all of the reading lists
                        string rejectedLink = string.Format("INSERT INTO ReadingListOwner (OwnerId, ReadingListId) VALUES ((select id from owner where username = '{0}'), (select id from readinglist where modulecode = '{1}'));", o.username, rejectedRl.ModuleCode);
                        Console.WriteLine(rejectedLink);
                        //Console.WriteLine(o.username + ": " + rejectedRl.ModuleCode + "(" + rejectedRl.ModuleTitle + ")");
                    }
                }
            }

            foreach(var duplicate in duplicateUsernames)
            {
                Console.WriteLine("Duplicate: " + duplicate);
            }
        }

        public static void ImportSemesters(string line, List<Semester> Semesters)
        {
            string substring = line.Substring(line.IndexOf("("));
            string[] separator = { "),(" };
            string[] records = substring.Split(separator, StringSplitOptions.None);
            foreach (string s in records)
            {
                try
                {
                    string record = s;
                    if (record.StartsWith("(")) record = record.Substring(1);

                    string[] attributes = record.Split(',');

                    Semester semester = new Semester()
                    {
                        ID = Convert.ToInt32(attributes[0]),
                        Title = TidyString(attributes[1])
                    };

                    Semesters.Add(semester);
                }
                catch (Exception e)
                {

                }
            }
        }

        /// <summary>
        /// Import a line containing reading list data
        /// </summary>
        /// <param name="line"></param>
        /// <param name="ReadingLists"></param>
        /// <param name="RejectedReadingLists"></param>
        public static void ImportReadingLists(string line, List<ReadingList> ReadingLists, List<ReadingList> RejectedReadingLists)
        {//BN-D630-M0059-16
            string substring = line.Substring(line.IndexOf("("));
            string[] separator = { "),(" };
            string[] records = substring.Split(separator, StringSplitOptions.None);
            foreach (string s in records)
            {
                try
                {
                    string record = s;
                    if (record.StartsWith("(")) record = record.Substring(1);
                    if (record.EndsWith(");")) record = record.Substring(0, record.Length - 2);

                    //string[] delimiters = { "','", ","};
                    //string[] attributes = record.Split(delimiters, StringSplitOptions.None);
                    record = record.Replace("\\'", "\\#");
                    string[] attributes = Regex.Split(record, ",(?=(?:[^']*'[^']*')*[^']*$)");

                    ReadingList list = new ReadingList()
                    {
                        ID = Convert.ToInt32(attributes[0]),
                        ModuleCode = TidyString(attributes[1]),
                        ModuleTitle = TidyString(attributes[2]),
                        DeptCode = TidyString(attributes[3]),
                        Year = Convert.ToInt32(attributes[4])                        
                    };
                    int lasuSemesterID = attributes[16] == null || "NULL".Equals(attributes[16]) ? 0 : Convert.ToInt32(attributes[16]);
                    if (SemesterIDMap.ContainsKey(lasuSemesterID))
                    {
                        list.SemesterID = SemesterIDMap[lasuSemesterID];
                    }
                    else
                    {
                        // No idea what it is so give it the 'Any' one
                        list.SemesterID = 1;
                    }


                    if (list.ModuleCode.EndsWith("-16"))
                    {
                        list.ModuleCode = list.ModuleCode.Substring(0, list.ModuleCode.Length - 3);
                        ReadingLists.Add(list);
                    }
                    else
                    {
                        RejectedReadingLists.Add(list);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Failed on " + s);
                }
            }
        }

        /// <summary>
        /// Import a line containing owner data
        /// </summary>
        /// <param name="line"></param>
        /// <param name="ImportableOwners"></param>
        public static void ImportOwners(string line, Dictionary<Owner, List<Owner>> ImportableOwners)
        {
            // owner line
            string substring = line.Substring(line.IndexOf("("));
            //Console.WriteLine(substring);
            string[] separator = { "),(" };
            string[] records = substring.Split(separator, StringSplitOptions.None);
            foreach (string s in records)
            {
                try
                {
                    string record = s;
                    if (record.StartsWith("(")) record = record.Substring(1);
                    //Console.WriteLine(record);

                    string[] attributes = record.Split(',');
                    DateTime dateTime = DateTime.MinValue;
                    try {
                        dateTime = DateTime.ParseExact(TidyString(attributes[5], false), "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                    }
                    catch(Exception ex)
                    {
                        Console.WriteLine("Failed to parse date: " + TidyString(attributes[5]));
                    }

                    Owner newestVersionOfThisOwner = new Owner()
                    {
                        readingListID = Convert.ToInt32(TidyString(attributes[0])),
                        fullname = TidyString(attributes[1]),
                        username = TidyString(attributes[2]).ToUpper(),
                        email = TidyString(attributes[4]),
                        lastModified = dateTime
                    };

                    // Is this more up to date than the owner we already have with this username?
                    if (ImportableOwners.ContainsKey(newestVersionOfThisOwner))
                    {
                        Owner bestOwnerSoFar = ImportableOwners.Keys.Where(x => x.Equals(newestVersionOfThisOwner)).SingleOrDefault();
                        if (bestOwnerSoFar.lastModified < newestVersionOfThisOwner.lastModified)
                        {
                            // The newer version is more up to date, so use him instead and add the current best to the dog pile
                            List<Owner> currentRejects = ImportableOwners[bestOwnerSoFar];
                            currentRejects.Add(bestOwnerSoFar);
                            ImportableOwners.Remove(bestOwnerSoFar);
                            ImportableOwners.Add(newestVersionOfThisOwner, currentRejects);
                        }
                        else
                        {
                            // We already have a more up to date version of this owner, so just add this to the list of rejects
                            ImportableOwners[bestOwnerSoFar].Add(newestVersionOfThisOwner);
                        }
                    }
                    else
                    {
                        // Not seen this user before, add them as the key because they are by default, the best version to use
                        ImportableOwners.Add(newestVersionOfThisOwner, new List<Owner>());
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("Error parsing: " + line);
                    Console.WriteLine(e);
                }
            }

        }

        /// <summary>
        /// Print out the owners we have
        /// </summary>
        public static void OwnerReport(Dictionary<Owner, List<Owner>> ImportableOwners, string lastNameOfOwnerToDisplay)
        {
            // Examine the owners
            Console.WriteLine("Found " + ImportableOwners.Keys.Count + " unique owners");

            if(!string.IsNullOrEmpty(lastNameOfOwnerToDisplay))
            {
                foreach (var kvp in ImportableOwners)
                {
                    if (kvp.Key.GetLastName().Equals(lastNameOfOwnerToDisplay))
                    {
                        //Console.WriteLine("** " + kvp.Key);
                        foreach (var reject in kvp.Value.OrderByDescending(x => x.lastModified).ToList())
                        {
                            Console.WriteLine("Rejected Owner: " + reject);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Debug for semesters
        /// </summary>
        /// <param name="Semesters"></param>
        public static void SemesterReport(List<Semester> Semesters)
        {
            Console.WriteLine("Semesters\n----------------------");
            foreach (var s in Semesters)
            {
                Console.WriteLine(s);
            }
        }

        /// <summary>
        /// Debug for reading lists
        /// </summary>
        /// <param name="ReadingLists"></param>
        /// <param name="RejectedReadingLists"></param>
        public static void ReadingListReport(List<ReadingList> ReadingLists, List<ReadingList> RejectedReadingLists)
        {
            Console.WriteLine("Imported Modules (total " + ReadingLists.Count() + ")");
            Console.WriteLine("==================================================");
            foreach (ReadingList rl in ReadingLists)
            {
                Console.WriteLine(rl);
            }

            Console.WriteLine("\nOld modules not imported (total " + RejectedReadingLists.Count() + ")");
            Console.WriteLine("==================================================");
            foreach (ReadingList rl in RejectedReadingLists)
            {
                Console.WriteLine(rl);
            }
        }

        /// <summary>
        /// Remove quotes and other stuff we dont want in any strings
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static string TidyString(string s, bool colons = true)
        {
            if (s != null)
            {
                if (s.StartsWith("'")) s = s.Substring(1);
                if (s.EndsWith("');")) s = s.Substring(0, s.Length - 3);
                if (s.EndsWith("'")) s = s.Substring(0, s.Length - 1);
                s = s.Replace("\\'", "''");
                s = s.Replace("\\#", "''");
                s = s.Replace("’", "''");
                if (colons)
                {
                    // Only do colons if told to do so, this messes up dates
                    s = s.Replace(":", "::");
                }
                s = s.Trim();
            }
            return s;
        }
    }
}
