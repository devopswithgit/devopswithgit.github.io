﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEALRImportUtility2
{
    public class Semester
    {
        public int ID { get; set; }
        public string Title { get; set; }

        public override string ToString()
        {
            return "ID: " + ID + ", " +
                   "Title: " + Title;
        }

        public override bool Equals(Object o)
        {
            if (o == null) return false;
            if (this.ID.Equals(((Semester)o).ID))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return (ID + Title).GetHashCode();
        }
    }
}
